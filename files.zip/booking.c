/*
 * ============================================================
 *  BOOKING.C
 * ============================================================
 *  Handles booking a new seat and cancelling an existing
 *  booking.
 * ============================================================
 */

#include <stdio.h>
#include <string.h>
#include "bus_reservation.h"

/* ==========================================================
   BOOK A SEAT
   ========================================================== */
void bookSeat(void) {
    int row, col;
    char name[50], phone[15];

    displaySeatMap();

    printf("\n  Enter row number (1-%d): ", ROWS);
    if (scanf("%d", &row) != 1 || row < 1 || row > ROWS) {
        printf("  [!] Invalid row number.\n");
        clearInputBuffer();
        return;
    }
    clearInputBuffer();

    printf("  Enter column number (1-%d): ", COLS);
    if (scanf("%d", &col) != 1 || col < 1 || col > COLS) {
        printf("  [!] Invalid column number.\n");
        clearInputBuffer();
        return;
    }
    clearInputBuffer();

    /* Convert to 0-based index */
    row--; col--;

    if (seats[row][col] == 1) {
        printf("  [!] Seat Row %d Col %d is already booked!\n", row+1, col+1);
        return;
    }

    printf("  Enter passenger name  : ");
    fgets(name, sizeof(name), stdin);
    name[strcspn(name, "\n")] = '\0';
    if (strlen(name) == 0) {
        printf("  [!] Name cannot be empty.\n");
        return;
    }

    printf("  Enter phone number    : ");
    fgets(phone, sizeof(phone), stdin);
    phone[strcspn(phone, "\n")] = '\0';
    if (strlen(phone) == 0) {
        printf("  [!] Phone cannot be empty.\n");
        return;
    }

    /* Save booking */
    seats[row][col] = 1;
    passengers[totalPassengers].row    = row;
    passengers[totalPassengers].col    = col;
    passengers[totalPassengers].active = 1;
    strncpy(passengers[totalPassengers].name,  name,  49);
    strncpy(passengers[totalPassengers].phone, phone, 14);
    totalPassengers++;

    printf("\n");
    printLine('=', 40);
    printf("  BOOKING CONFIRMED!\n");
    printf("  Seat   : Row %d, Column %d\n", row+1, col+1);
    printf("  Name   : %s\n", name);
    printf("  Phone  : %s\n", phone);
    printf("  Price  : RM %.2f\n", TICKET_PRICE);
    printLine('=', 40);
}

/* ==========================================================
   CANCEL A SEAT
   ========================================================== */
void cancelSeat(void) {
    int row, col;

    displaySeatMap();

    printf("\n  Enter row of seat to cancel (1-%d): ", ROWS);
    if (scanf("%d", &row) != 1 || row < 1 || row > ROWS) {
        printf("  [!] Invalid row.\n");
        clearInputBuffer();
        return;
    }
    clearInputBuffer();

    printf("  Enter column of seat to cancel (1-%d): ", COLS);
    if (scanf("%d", &col) != 1 || col < 1 || col > COLS) {
        printf("  [!] Invalid column.\n");
        clearInputBuffer();
        return;
    }
    clearInputBuffer();

    row--; col--;

    if (seats[row][col] == 0) {
        printf("  [!] Seat Row %d Col %d is not booked.\n", row+1, col+1);
        return;
    }

    /* Find and remove passenger */
    for (int i = 0; i < totalPassengers; i++) {
        if (passengers[i].row == row && passengers[i].col == col && passengers[i].active) {
            printf("\n  Cancelling booking for: %s\n", passengers[i].name);
            passengers[i].active = 0;
            seats[row][col] = 0;
            totalPassengers--;
            /* Shift array */
            for (int j = i; j < totalPassengers; j++)
                passengers[j] = passengers[j+1];
            printf("  [OK] Booking cancelled successfully.\n");
            return;
        }
    }
    printf("  [!] Error: passenger record not found.\n");
}
