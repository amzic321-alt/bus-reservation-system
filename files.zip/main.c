/*
 * ============================================================
 *  BUS TICKET RESERVATION SYSTEM
 *  Group 7 - Programming Fundamentals Final Project
 * ============================================================
 *  MAIN.C - Program entry point and menu loop.
 *  All feature logic lives in its own file:
 *    seat_map.c, booking.c, passenger_search.c,
 *    ticket.c, storage.c, utils.c
 * ============================================================
 */

#include <stdio.h>
#include "bus_reservation.h"

int main(void) {
    int choice;

    loadBookings();

    do {
        printf("\n");
        printLine('=', 40);
        printf("   BUS TICKET RESERVATION SYSTEM\n");
        printLine('=', 40);
        printf("  [1] View Seat Map\n");
        printf("  [2] Book a Seat\n");
        printf("  [3] Cancel a Booking\n");
        printf("  [4] Search Passenger\n");
        printf("  [5] Print Ticket\n");
        printf("  [0] Exit\n");
        printLine('-', 40);
        printf("  Enter choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("  [!] Invalid input. Please enter a number.\n");
            clearInputBuffer();
            continue;
        }
        clearInputBuffer();

        switch (choice) {
            case 1: displaySeatMap();   break;
            case 2: bookSeat();         break;
            case 3: cancelSeat();       break;
            case 4: searchPassenger();  break;
            case 5: printTicket();      break;
            case 0:
                saveBookings();
                printf("\n  Bookings saved. Goodbye!\n\n");
                break;
            default:
                printf("  [!] Invalid option. Try again.\n");
        }
    } while (choice != 0);

    return 0;
}
