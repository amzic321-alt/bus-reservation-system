/*
 * ============================================================
 *  UTILS.C
 * ============================================================
 *  Small helper functions used across the program.
 * ============================================================
 */

#include <stdio.h>
#include "bus_reservation.h"

void printLine(char c, int len) {
    for (int i = 0; i < len; i++) printf("%c", c);
    printf("\n");
}

void clearInputBuffer(void) {
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF);
}
