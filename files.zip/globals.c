/*
 * ============================================================
 *  GLOBALS.C - Shared Global Data Definitions
 * ============================================================
 *  Holds the actual storage for the seat map, passenger list,
 *  and passenger counter used across every source file.
 * ============================================================
 */

#include "bus_reservation.h"

int       seats[ROWS][COLS];          /* 0=available, 1=booked */
Passenger passengers[MAX_PASS];
int       totalPassengers = 0;
