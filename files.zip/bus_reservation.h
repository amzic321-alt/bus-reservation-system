/*
 * ============================================================
 *  BUS TICKET RESERVATION SYSTEM - Shared Header
 *  Group 7 - Programming Fundamentals Final Project
 * ============================================================
 *  Contains: constants, struct definitions, and function
 *  prototypes shared across all source files.
 * ============================================================
 */

#ifndef BUS_RESERVATION_H
#define BUS_RESERVATION_H

/* ── Constants ─────────────────────────────────────── */
#define ROWS         5
#define COLS         4
#define MAX_PASS     (ROWS * COLS)
#define FILE_NAME    "bookings.txt"
#define TICKET_PRICE 15.00

/* ── Struct ─────────────────────────────────────────── */
typedef struct {
    char name[50];
    char phone[15];
    int  row;
    int  col;
    int  active;   /* 1 = booked, 0 = empty slot */
} Passenger;

/* ── Shared Global Data (defined in globals.c) ──────── */
extern int       seats[ROWS][COLS];   /* 0=available, 1=booked */
extern Passenger passengers[MAX_PASS];
extern int       totalPassengers;

/* ── Function Prototypes ────────────────────────────── */

/* seat_map.c */
void displaySeatMap(void);

/* booking.c */
void bookSeat(void);
void cancelSeat(void);

/* passenger_search.c */
void searchPassenger(void);

/* ticket.c */
void printTicket(void);

/* storage.c */
void saveBookings(void);
void loadBookings(void);

/* utils.c */
void printLine(char c, int len);
void clearInputBuffer(void);

#endif /* BUS_RESERVATION_H */
